@include('partials.head')

@include('partials.nav')
